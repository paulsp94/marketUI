<?php

require_once 'client/dist/client-script.php';

?>

<html>
<head>
    <title>Password Saves</title>
</head>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/latest/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css?family=Bree+Serif" rel="stylesheet">
<script language="JavaScript" type="text/javascript" src="jsbn2.js"></script>
<script language="JavaScript" type="text/javascript" src="rsa.js"></script>


<body>

<div id="js-main" class="main_load"></div>

<script async src="client/dist/<?=$client_script?>"></script>

</body>
</html>

